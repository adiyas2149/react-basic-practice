import React from "react";
import { Text, StyleSheet,View,Button, TouchableOpacity} from "react-native";

const HomeScreen = ({ navigation }) => {
  return <View>
    <Text style={styles.text}>hii aditya</Text>
    <Button
    onPress={() => navigation.navigate('Components')}
     title="tap to components" />
     <Button
    onPress={() => navigation.navigate('List')}
     title="tap to List page" />
     <Button
    onPress={() => navigation.navigate('Image')}
     title="tap to imagescreen" />
     <Button
    onPress={() => navigation.navigate('Counter')}
     title="tap to CounterScreen" />
     <Button
    onPress={() => navigation.navigate('Color')}
     title="tap to colors Page" />
     <Button
    onPress={() => navigation.navigate('Square')}
     title="tap to SquareScreen Page" />
     <Button
    onPress={() => navigation.navigate('Text')}
     title="tap toName Text page" />
     
    </View>
};

const styles = StyleSheet.create({
  text: {
    fontSize: 30
    
  }
});

export default HomeScreen;
