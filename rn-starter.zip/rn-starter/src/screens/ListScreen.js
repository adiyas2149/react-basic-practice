import React from "react";
import { View,Text, StyleSheet } from "react-native";
import { FlatList } from "react-native-gesture-handler";


const ListScreen = () =>{

    const friends=[
        { name : 'flana 1'},
        { name : 'flana 2'},
        { name : 'flana 3'},
        { name : 'flana 4'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
        { name : 'flana 5'},
    ];

    return (
        <FlatList
        keyExtractor={i=>i.name}
        data = {friends}
        renderItem={({ item }) => {
            return <Text style={styles.textStyle}>{item.name}</Text>;
        }
    }
    />
    );
};

const styles = StyleSheet.create({

    textStyle: {
        marginVertical: 50
    },
    bestStyle: {
        fontSize: 20
    }
});

export default ListScreen;